﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projeKayit
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public static class carpisma
        {  
            //1.cisim degerler
            public static float x1 { get; set; }
            public static float y1 { get; set; }
            public static float z1 { get; set; }
            public static float r1 { get; set; }
            public static float uzunluk1 { get; set; }
            public static float genislik1 { get; set; }
            public static float derinlik1 { get; set; }

            //2.cisim degerleri
            public static float x2 { get; set; }
            public static float y2 { get; set; }
            public static float z2 { get; set; }
            public static float r2 { get; set; }
            public static float uzunluk2 { get; set; }
            public static float genislik2 { get; set; }
            public static float derinlik2 { get; set; }

            public static void nok_dortgen()
            {
                if ( Math.Abs(x2-x1)<(genislik2/2) && Math.Abs(y2-y1) < (uzunluk2 / 2))
                {
                    MessageBox.Show("Carpisma Var");
                } else  MessageBox.Show("Carpisma yok");
            }
            public static void nok_cember()
            {
                if(Math.Abs(x2 - x1) <=r2 && Math.Abs(y2 - y1) <=r2 )
                {
                    MessageBox.Show("Carpisma Var");
                } else MessageBox.Show("Carpisma Yok");
            }
            public static void nok_kure()
            {
                if (Math.Abs(x2 - x1) <= r2 && Math.Abs(y2 - y1) <= r2)
                {
                    MessageBox.Show("Carpisma Var");
                }else MessageBox.Show("Carpisma Yok");
            }
            public static void nok_silindir()
            {
                if (Math.Abs(x2 - x1) <= r2 && Math.Abs(y2 - y1) <= (uzunluk2/2))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void nok_prizma()
            {
                if (Math.Abs(x2 - x1) <= (genislik2/2) && Math.Abs(y2 - y1) <=(uzunluk2/2))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void dortgen_dortgen()
            {
                if (Math.Abs(x2 - x1) <= ((genislik2 / 2) + (genislik1) / 2) && Math.Abs(y2 - y1) <= ((uzunluk2 / 2) + (uzunluk1 / 2)))
                {
                    MessageBox.Show("carpisma var");

                }
                else MessageBox.Show("carpisma yok");
            }
            public static void dortgen_cember()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1/2 )+ r2)  && Math.Abs(y2 - y1) <= ((uzunluk1/2) + r2) )
                    {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
           public static void cember_cember()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1 / 2) + r2) && Math.Abs(y2 - y1) <= ((uzunluk1 / 2) + r2))
                {
                    MessageBox.Show("carpisma var");
                }
                else MessageBox.Show("carpisma yok");

            }
            public static void kure_kure()
            {
                if (Math.Abs(x2 - x1) <= (r1 + r2) && Math.Abs(y2 - y1) <= (r1 + r2) && Math.Abs(z2-z1) <= (r1 + r2))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void kure_silindir()
            {
                if (Math.Abs(x2 - x1) <= (r1+r2) && Math.Abs(y2 - y1) <= (r1+ (uzunluk2/2)) && Math.Abs(z2 - z1) <= (r1 +(derinlik2/2)))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void kure_prizma()
            {

                if (Math.Abs(x2 - x1) <= (r1 + (genislik2 /2)) && Math.Abs(y2 - y1) <= (r1 + (uzunluk2 / 2)) && Math.Abs(z2 - z1) <= (r1 + (derinlik2 / 2)))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void silindir_silindir()
            {
                if (Math.Abs(x2 - x1) <= (r1 + r2) && Math.Abs(y2 - y1) <= ((uzunluk1/2) + (uzunluk2 / 2)) && Math.Abs(z2 - z1) <= (r1 + r2))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void prizma_prizma()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1+genislik2/2)) && Math.Abs(y2 - y1) <= ((uzunluk1 / 2) + (uzunluk2 / 2)) && Math.Abs(z2 - z1) <= ((derinlik1/2) + (derinlik2/2)) )
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void yuzey_kure()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1/2 + r2)) && Math.Abs(z2 - z1) <= ((derinlik1 / 2) + r2))
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void yuzey_silindir()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1 / 2 + r2)) && Math.Abs(z2 - z1) <= ((derinlik1 / 2) + r2) )
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }
            public static void yuzey_prizma()
            {
                if (Math.Abs(x2 - x1) <= ((genislik1 / 2 + genislik2 / 2)) && Math.Abs(z2 - z1) <= ((derinlik1 / 2) + derinlik2/ 2) )
                {
                    MessageBox.Show("Carpisma Var");
                }
                else MessageBox.Show("Carpisma Yok");
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex==0)
            { 
                //nokta
                Z1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //dikDortgen
                Z2.Enabled = false; R2.Enabled = false; Derinlik2.Enabled = false;
            }
             else if(comboBox1.SelectedIndex==1)
            {
                //nokta
                Z1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //Cember
                Z2.Enabled = false; Uzunluk2.Enabled = false; Genislik2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                //nokta
                Z1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //Kure
                Z2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                //nokta
                Z1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //Silindir
                Z2.Enabled = false; Genislik2.Enabled = false; 
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                //nokta
                Z1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //prizma
                R2.Enabled = false;
            }
            else if (comboBox2.SelectedIndex==0)
            {
                //1.dik dortgen
                Z1.Enabled = false; R1.Enabled = false; Derinlik1.Enabled = false;
                //2.dik dortgen
                Z2.Enabled = false; R2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                //1.dik dortgen
                Z1.Enabled = false; R1.Enabled = false; Derinlik1.Enabled = false;
                //Cember
                Z2.Enabled = false; Uzunluk2.Enabled = false; Genislik2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox3.SelectedIndex==0)
            {
                //1.Cember
                Z1.Enabled = false; Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //2.Cember
                Z2.Enabled = false; Uzunluk2.Enabled = false; Genislik2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox4.SelectedIndex==0)
            {
                //1.kure
                Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //2.kure
                Uzunluk2.Enabled = false; Genislik2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox4.SelectedIndex == 1)
            {
                //1.kure
                Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //Silindir
                Genislik2.Enabled = false;
            }
            else if (comboBox4.SelectedIndex == 2)
            {
                //1.kure
                Uzunluk1.Enabled = false; Genislik1.Enabled = false; Derinlik1.Enabled = false;
                //Prizma
                R2.Enabled = false;
            }
            else if (comboBox5.SelectedIndex==0)
            {
                //1.silindir
                Genislik1.Enabled = false;
                //2.Silindir
                Genislik2.Enabled = false;
            }
            else if (comboBox6.SelectedIndex==0)
            {
                //1.prizma
                R1.Enabled = false;
                //2.prizma
                R2.Enabled = false;
            }
            else if (comboBox7.SelectedIndex==0)
            {
                //yuzey 
                Y1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false;

                //kure
                Uzunluk2.Enabled = false; Genislik2.Enabled = false; Derinlik2.Enabled = false;
            }
            else if (comboBox7.SelectedIndex == 1)
            {
                //yuzey 
                Y1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false;

                //2.Silindir
                Genislik2.Enabled = false;
            }
            else if (comboBox7.SelectedIndex == 2)
            {
                //yuzey 
                Y1.Enabled = false; R1.Enabled = false; Uzunluk1.Enabled = false;

                //2.prizma
                R2.Enabled = false;
            }
            button2.Enabled = true;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == 0)
            {
                //nokta 
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                //dikdortgen
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);

                carpisma.nok_dortgen();
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                //nokta 
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                //cember
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.nok_cember();
            }
            else if (comboBox1.SelectedIndex == 2)
            {
                //nokta 
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                //kure
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.nok_kure();
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                //nokta 
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                //silindir
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.nok_silindir();

            }
            else if (comboBox1.SelectedIndex == 4)
            {
                //nokta 
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                //prizma
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);
                carpisma.derinlik2 = float.Parse(Derinlik2.Text);
                carpisma.nok_prizma();
            }
            else if (comboBox2.SelectedIndex == 0)
            {
                //1.dikdortgen
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.uzunluk1 = float.Parse(Uzunluk1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                //2.dikdortgen
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);
                carpisma.dortgen_dortgen();
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                //1.dikdortgen
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.uzunluk1 = float.Parse(Uzunluk1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                //cember
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.dortgen_cember();

            }
            else if (comboBox3.SelectedIndex == 0)
            {
                //1.cember
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.r1 = float.Parse(R1.Text);

                //cember
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.cember_cember();

            }
            else if (comboBox4.SelectedIndex == 0)
            {
                //1.kure
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.r1 = float.Parse(R1.Text);
                //2.kure
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.kure_kure();
            }
            else if (comboBox4.SelectedIndex == 1)
            {
                //kure
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.r1 = float.Parse(R1.Text);
                //silindir
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.kure_silindir();
            }
            else if (comboBox4.SelectedIndex == 2)
            {
                //kure
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.r1 = float.Parse(R1.Text);
                //prizma
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);
                carpisma.derinlik2 = float.Parse(Derinlik2.Text);
                carpisma.kure_prizma();
            }
            else if (comboBox5.SelectedIndex == 0)
            {
                //1.silindir
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.r1 = float.Parse(R1.Text);
                carpisma.uzunluk1 = float.Parse(Uzunluk1.Text);

                //2.silindir
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.silindir_silindir();
            }
            else if (comboBox6.SelectedIndex == 0)
            {
                //1.prizma
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.y1 = float.Parse(Y1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.uzunluk1 = float.Parse(Uzunluk1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                carpisma.derinlik1 = float.Parse(Derinlik1.Text);
                //2.prizma
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);
                carpisma.derinlik2 = float.Parse(Derinlik2.Text);

                carpisma.prizma_prizma();
            }
            else if (comboBox7.SelectedIndex == 0)
            {
                //yuzey
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                carpisma.derinlik1 = float.Parse(Derinlik1.Text);
                //kure

                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.yuzey_kure();
            }


            else if (comboBox7.SelectedIndex == 1)
            {
                //yuzey
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                carpisma.derinlik1 = float.Parse(Derinlik1.Text);

                //silindir
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.r2 = float.Parse(R2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.yuzey_silindir();
            }
            else if (comboBox7.SelectedIndex == 2)
            {
                //yuzey
                carpisma.x1 = float.Parse(X1.Text);
                carpisma.z1 = float.Parse(Z1.Text);
                carpisma.genislik1 = float.Parse(Genislik1.Text);
                carpisma.derinlik1 = float.Parse(Derinlik1.Text);
                //prizma
                carpisma.x2 = float.Parse(X2.Text);
                carpisma.y2 = float.Parse(Y2.Text);
                carpisma.z2 = float.Parse(Z2.Text);
                carpisma.uzunluk2 = float.Parse(Uzunluk2.Text);
                carpisma.genislik2 = float.Parse(Genislik2.Text);
                carpisma.derinlik2 = float.Parse(Derinlik2.Text);
                carpisma.yuzey_prizma();

            }
            button3.Enabled = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (comboBox1.SelectedIndex == 0)
            {   
                //nokta
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.BlueViolet,x1,y1, 4, 4);
              
                //dikdortgen
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.CadetBlue);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2, y2, genislik2, uzunluk2);
            }

            else if (comboBox1.SelectedIndex == 1)
            {
                //nokta
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.BlueViolet, x1, y1, 4, 4);

                //cember
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                Pen p = new Pen(Color.Coral);
                pictureBox1.CreateGraphics().DrawEllipse(p, x2, y2, r2, r2);

            }
            else if (comboBox1.SelectedIndex == 2)
            {
                //nokta
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.BlueViolet, x1, y1, 4, 4);

                //cember
                float x2 = float.Parse(X1.Text);
                float y2 = float.Parse(Y1.Text);
                float r2 = float.Parse(R2.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.DarkGreen, x1, y1, r2, r2);
            }
            else if (comboBox1.SelectedIndex == 3)
            {
                //nokta
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.BlueViolet, x1, y1, 4, 4);

                //Silindir
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);

                Pen p = new Pen(Color.Tan);
                Point[] point = new Point[2];
                Rectangle rec = new Rectangle((int)x2, (int)y2, (int)r2, (int)uzunluk2);

                point[0] = new Point(rec.Left, rec.Top);
                point[1] = new Point(rec.Right, rec.Top);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)y2, (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)(y2 + uzunluk2), (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawRectangle(p, (float)x2, (float)(y2 + uzunluk2 / 2), (float)r2, (float)uzunluk2);
            }
            else if (comboBox1.SelectedIndex == 4)
            {
                //nokta
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.BlueViolet, x1, y1, 4, 4);

                //prizma
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.DarkGoldenrod);
                Rectangle rec1 = new Rectangle((int)x2, (int)y2,(int) genislik2, (int) uzunluk2);
                Rectangle rec2 = new Rectangle((int)(x2 + genislik2), (int)(y2+uzunluk2), (int)genislik2, (int)uzunluk2);
                Point[] point = new Point[8];
                point[0] = new Point(rec1.Left,rec1.Top);
                point[1] = new Point(rec1.Right, rec1.Top);
                point[2] = new Point(rec1.Left, rec1.Bottom);
                point[3] = new Point(rec1.Right, rec1.Bottom);
                point[4] = new Point(rec2.Left, rec2.Top);
                point[5] = new Point(rec2.Right, rec2.Top);
                point[6] = new Point(rec2.Left, rec2.Bottom);
                point[7] = new Point(rec2.Right, rec2.Bottom);
                pictureBox1.CreateGraphics().DrawRectangle(p,x2,y2,genislik2,uzunluk2);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2 +genislik2, y2+uzunluk2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawLines(p, point);
            }
            else if (comboBox2.SelectedIndex == 0)
            {
                //1.dikdortgen
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float uzunluk1 = float.Parse(Uzunluk1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                Pen p1 = new Pen(Color.CadetBlue);
                pictureBox1.CreateGraphics().DrawRectangle(p1, x1, y1, genislik1, uzunluk1);

                //2.dikdortgen
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.Crimson);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2, y2, genislik2, uzunluk2);
            }
            else if (comboBox2.SelectedIndex == 1)
            {
                //1.dikdortgen
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float uzunluk1 = float.Parse(Uzunluk1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                Pen p1 = new Pen(Color.CadetBlue);
                pictureBox1.CreateGraphics().DrawRectangle(p1, x1, y1, genislik1, uzunluk1);

                //cember
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                Pen p2 = new Pen(Color.DeepPink);
                pictureBox1.CreateGraphics().DrawEllipse(p2, x2, y2, r2, r2);
            }
            else if (comboBox3.SelectedIndex == 0)
            {
                //cember
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float r1 = float.Parse(R1.Text);
                Pen p1 = new Pen(Color.DeepPink);
                pictureBox1.CreateGraphics().DrawEllipse(p1, x1, y1, r1, r1);
                //cember
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                Pen p2 = new Pen(Color.Goldenrod);
                pictureBox1.CreateGraphics().DrawEllipse(p2, x2, y2, r2, r2);
            }
            else if (comboBox4.SelectedIndex == 0)
            {
                //KURE
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float r1 = float.Parse(R1.Text);
                
                pictureBox1.CreateGraphics().FillEllipse(Brushes.SandyBrown, x1, y1, r1, r1);
                //KURE
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.SpringGreen, x2, y2, r2, r2);
            }
            else if (comboBox4.SelectedIndex == 1)
            {

                //KURE
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float r1 = float.Parse(R1.Text);

                pictureBox1.CreateGraphics().FillEllipse(Brushes.SeaGreen, x1, y1, r1, r1);
                //silindir
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);

                Pen p = new Pen(Color.Tan);
                Point[] point = new Point[2];
                Rectangle rec = new Rectangle((int)x2, (int)y2, (int)r2, (int)uzunluk2);

                point[0] = new Point(rec.Left, rec.Top);
                point[1] = new Point(rec.Right, rec.Top);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)y2, (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)(y2 + uzunluk2), (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawRectangle(p, (float)x2, (float)(y2 + uzunluk2 / 2), (float)r2, (float)uzunluk2);
            }
            else if (comboBox4.SelectedIndex == 2)
            {
                //KURE
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float r1 = float.Parse(R1.Text);

                pictureBox1.CreateGraphics().FillEllipse(Brushes.YellowGreen, x1, y1, r1, r1);
                //prizma
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.DarkGoldenrod);
                Rectangle rec1 = new Rectangle((int)x2, (int)y2, (int)genislik2, (int)uzunluk2);
                Rectangle rec2 = new Rectangle((int)(x2 + genislik2), (int)(y2 + uzunluk2), (int)genislik2, (int)uzunluk2);
                Point[] point = new Point[8];
                point[0] = new Point(rec1.Left, rec1.Top);
                point[1] = new Point(rec2.Left, rec2.Top);
                point[2] = new Point(rec1.Right, rec1.Top);
                point[3] = new Point(rec2.Right, rec2.Top);
                point[4] = new Point(rec1.Left, rec1.Bottom);
                point[5] = new Point(rec2.Left, rec2.Bottom);
                point[6] = new Point(rec1.Right, rec1.Bottom);
                point[7] = new Point(rec2.Right, rec2.Bottom);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2, y2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2 + genislik2, y2 + uzunluk2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawLines(p, point);
            }
            else if (comboBox5.SelectedIndex == 0)
            {
                //1.Silindir
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float r1 = float.Parse(R1.Text);
                float uzunluk1 = float.Parse(Uzunluk1.Text);

                Pen p1 = new Pen(Color.DarkOrange);
                Point[] point1 = new Point[2];
                Rectangle rec1 = new Rectangle((int)x1, (int)y1, (int)r1, (int)uzunluk1);

                point1[0] = new Point(rec1.Left, rec1.Top);
                point1[1] = new Point(rec1.Right, rec1.Top);
                pictureBox1.CreateGraphics().DrawEllipse(p1,(float) x1, (float)y1,(float) r1, (float)r1);
                pictureBox1.CreateGraphics().DrawEllipse(p1, (float)x1, (float)(y1 + uzunluk1), (float)r1, (float)r1);
                pictureBox1.CreateGraphics().DrawRectangle(p1, (float)x1, (float)(y1 + uzunluk1 / 2), (float)r1, (float)uzunluk1);

                //2.Silindir
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);

                Pen p = new Pen(Color.Tan);
                Point[] point = new Point[2];
                Rectangle rec = new Rectangle((int)x2, (int)y2, (int)r2, (int)uzunluk2);

                point[0] = new Point(rec.Left, rec.Top);
                point[1] = new Point(rec.Right, rec.Top);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)y2, (float)r2,(float)r2);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)(y2 + uzunluk2), (float)r2,(float)r2);
                pictureBox1.CreateGraphics().DrawRectangle(p, (float)x2, (float)(y2 + uzunluk2 / 2), (float)r2, (float)uzunluk2);
            }
            else if (comboBox6.SelectedIndex == 0)
            {
                //prizma
                float x1 = float.Parse(X1.Text);
                float y1 = float.Parse(Y1.Text);
                float uzunluk1 = float.Parse(Uzunluk1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                Pen p1 = new Pen(Color.DarkGoldenrod);
                Rectangle rec1 = new Rectangle((int)x1, (int)y1, (int)genislik1, (int)uzunluk1);
                Rectangle rec2 = new Rectangle((int)(x1 + genislik1), (int)(y1 + uzunluk1), (int)genislik1, (int)uzunluk1);
                Point[] point1 = new Point[8];
                point1[0] = new Point(rec1.Left, rec1.Top);
                point1[1] = new Point(rec2.Left, rec2.Top);
                point1[2] = new Point(rec1.Right, rec1.Top);
                point1[3] = new Point(rec2.Right, rec2.Top);
                point1[4] = new Point(rec1.Left, rec1.Bottom);
                point1[5] = new Point(rec2.Left, rec2.Bottom);
                point1[6] = new Point(rec1.Right, rec1.Bottom);
                point1[7] = new Point(rec2.Right, rec2.Bottom);



                pictureBox1.CreateGraphics().DrawRectangle(p1, x1, y1, genislik1, uzunluk1);
                pictureBox1.CreateGraphics().DrawRectangle(p1, x1 + genislik1, y1 + uzunluk1, genislik1, uzunluk1);
                pictureBox1.CreateGraphics().DrawLines(p1, point1);
                //prizma
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.MediumSlateBlue);
                Rectangle rec3 = new Rectangle((int)x2, (int)y2, (int)genislik2, (int)uzunluk2);
                Rectangle rec4 = new Rectangle((int)(x2 + genislik2), (int)(y2 + uzunluk2), (int)genislik2, (int)uzunluk2);
                Point[] point = new Point[8];
                point[0] = new Point(rec3.Left, rec3.Top);
                point[1] = new Point(rec4.Left, rec4.Top);
                point[2] = new Point(rec3.Right, rec3.Top);
                point[3] = new Point(rec4.Right, rec4.Top);
                point[4] = new Point(rec3.Left, rec3.Bottom);
                point[5] = new Point(rec4.Left, rec4.Bottom);
                point[6] = new Point(rec3.Right, rec3.Bottom);
                point[7] = new Point(rec4.Right, rec4.Bottom);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2, y2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2 + genislik2, y2 + uzunluk2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawLines(p, point);
            }
            else if (comboBox7.SelectedIndex == 0)
            {
                //yuzey 
                float x1 = float.Parse(X1.Text);
                float z1 = float.Parse(Z1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                float derinlik1 = float.Parse(Derinlik1.Text);
                pictureBox1.CreateGraphics().FillRectangle(Brushes.Navy, x1, z1, genislik1, derinlik1);


                //KURE
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                pictureBox1.CreateGraphics().FillEllipse(Brushes.SpringGreen, x2, y2, r2, r2);
            }
            else if (comboBox7.SelectedIndex == 1)
            {
                //yuzey 
                float x1 = float.Parse(X1.Text);
                float z1 = float.Parse(Z1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                float derinlik1 = float.Parse(Derinlik1.Text);
                pictureBox1.CreateGraphics().FillRectangle(Brushes.Navy, x1, z1, genislik1, derinlik1);


                //Silindir
               
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float r2 = float.Parse(R2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);

                Pen p = new Pen(Color.Tan);
                Point[] point = new Point[2];
                Rectangle rec = new Rectangle((int)x2, (int)y2, (int)r2, (int)uzunluk2);

                point[0] = new Point(rec.Left, rec.Top);
                point[1] = new Point(rec.Right, rec.Top);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)y2, (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawEllipse(p, (float)x2, (float)(y2 + uzunluk2), (float)r2, (float)r2);
                pictureBox1.CreateGraphics().DrawRectangle(p, (float)x2, (float)(y2 + uzunluk2 / 2), (float)r2, (float)uzunluk2);
            }
            else if (comboBox7.SelectedIndex == 2)
            {
                //yuzey 
                float x1 = float.Parse(X1.Text);
                float z1 = float.Parse(Z1.Text);
                float genislik1 = float.Parse(Genislik1.Text);
                float derinlik1 = float.Parse(Derinlik1.Text);
                pictureBox1.CreateGraphics().FillRectangle(Brushes.Navy, x1, z1, genislik1, derinlik1);

                //prizma
                float x2 = float.Parse(X2.Text);
                float y2 = float.Parse(Y2.Text);
                float uzunluk2 = float.Parse(Uzunluk2.Text);
                float genislik2 = float.Parse(Genislik2.Text);
                Pen p = new Pen(Color.MediumSlateBlue);
                Rectangle rec3 = new Rectangle((int)x2, (int)y2, (int)genislik2, (int)uzunluk2);
                Rectangle rec4 = new Rectangle((int)(x2 + genislik2), (int)(y2 + uzunluk2), (int)genislik2, (int)uzunluk2);
                Point[] point = new Point[8];
                point[0] = new Point(rec3.Left, rec3.Top);
                point[1] = new Point(rec4.Left, rec4.Top);
                point[2] = new Point(rec3.Right, rec3.Top);
                point[3] = new Point(rec4.Right, rec4.Top);
                point[4] = new Point(rec3.Left, rec3.Bottom);
                point[5] = new Point(rec4.Left, rec4.Bottom);
                point[6] = new Point(rec3.Right, rec3.Bottom);
                point[7] = new Point(rec4.Right, rec4.Bottom);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2, y2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawRectangle(p, x2 + genislik2, y2 + uzunluk2, genislik2, uzunluk2);
                pictureBox1.CreateGraphics().DrawLines(p, point);
            }
        }
    }
}
