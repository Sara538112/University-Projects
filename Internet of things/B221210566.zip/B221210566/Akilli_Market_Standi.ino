#include <HX711.h>
#include <ESP8266WiFi.h>
#include <FirebaseESP8266.h>
#include <time.h> // For timestamp
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>
#include <LiquidCrystal_I2C.h> // LCD için gerekli kütüphane

// Wi-Fi bağlantı bilgileri
#define WIFI_SSID "Sara"
#define WIFI_PASSWORD "6i6ctgmrmcyxxx3"

// Firebase bilgileri
#define FIREBASE_HOST "akilli-market-standi-default-rtdb.europe-west1.firebasedatabase.app"
#define FIREBASE_AUTH "iDwYX4cJpg2K6eako6Z1Weh1peoD2d6SvmeJVEKF"

// HX711 pinleri
#define DT D1
#define SCK D2
HX711 scale;

// LCD ekran tanımlaması (I2C adresi, 16x2 LCD ekran)
LiquidCrystal_I2C lcd(0x27, 16, 2);  // LCD adresi 0x27 varsayılmıştır

// Ürün bilgisi
#define PRODUCT_WEIGHT 200.0 // Tek ürünün ağırlığı (gram)
#define PRODUCT_NAME "Meyve Suyu"

// Firebase ile bağlantı için gerekli nesneler
FirebaseData firebaseData;
FirebaseConfig firebaseConfig;
FirebaseAuth firebaseAuth;

// Ürün sayıları
int totalProducts = 0;
int previousProducts = 0;

void setup() {
  // Seri haberleşmeyi başlat
  Serial.begin(115200);

  // Wi-Fi bağlantısı
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" Connected!");

  // Firebase yapılandırması
  firebaseConfig.host = FIREBASE_HOST;
  firebaseConfig.signer.tokens.legacy_token = FIREBASE_AUTH;
  Firebase.begin(&firebaseConfig, &firebaseAuth);

  // HX711 sensörünü başlat
  scale.begin(DT, SCK);
  scale.set_scale(2280.f);  // Kalibrasyon katsayısını ayarla (kendi kalibrasyon değerinizi kullanın)
  scale.tare();  // Başlangıçta sıfırlama

  // LCD ekranını başlat
  lcd.begin(16, 2);
  lcd.setBacklight(true);
  lcd.print("Starting...");

  // Zaman senkronizasyonu
  configTime(3 * 3600, 0, "pool.ntp.org", "time.nist.gov");
  Serial.println("Synchronizing time...");
  while (!time(nullptr)) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" Time synchronized!");

  // Başlangıç ürün sayısını hesapla
  totalProducts = calculateProducts();
  previousProducts = totalProducts;

  // Başlangıç verilerini Firebase'e gönder
  sendToFirebase(totalProducts);
}

void loop() {
  int currentProducts = calculateProducts(); // Şu anki ürün sayısını hesapla

  // LCD ekranında güncel ürün sayısını göster
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Total: ");
  lcd.print(currentProducts);
  lcd.setCursor(0, 1);
  lcd.print(PRODUCT_NAME);

  // Eğer stok sayısı azalmışsa (satılmışsa)
  if (currentProducts < previousProducts) {
    int soldProducts = previousProducts - currentProducts;
    saveSoldProducts(soldProducts); // Satılan ürünleri Firebase'e kaydet
  }

  // Firebase'e ürün sayısını güncelle
  if (Firebase.setInt(firebaseData, "/products/totalProducts", currentProducts)) {
    Serial.println("Updated total products in Firebase.");
  } else {
    Serial.print("Error: ");
    Serial.println(firebaseData.errorReason());
  }

  previousProducts = currentProducts;
  delay(5000);  // 5 saniye bekle
}

// Ürün sayısını hesaplamak için fonksiyon
int calculateProducts() {
  float totalWeight = scale.get_units(10); // Ortalama ölçüm yap
  return totalWeight / PRODUCT_WEIGHT; // Ürün sayısını döndür
}

// Firebase'e toplam ürün sayısını gönderme fonksiyonu
void sendToFirebase(int count) {
  Firebase.setString(firebaseData, "/products/productName", PRODUCT_NAME);
  Firebase.setInt(firebaseData, "/products/totalProducts", count);
  Firebase.setString(firebaseData, "/products/timestamp", timestamp); 
}

// Satılan ürünleri Firebase'e kaydetme fonksiyonu
void saveSoldProducts(int count) {
  time_t now = time(nullptr);
  String timestamp = ctime(&now);
  timestamp.trim(); // Satır sonu karakterini temizle

  String path = "/soldProducts/";
  path += String(now);
  
  // Satılan ürün sayısını Firebase'e kaydet
  Firebase.pushInt(firebaseData, path + "/soldCount", count);
  Firebase.pushString(firebaseData, path + "/date", timestamp);

  Serial.println("Sold products logged to Firebase.");

  // Eğer satılan ürün sayısı toplam ürün sayısının yarısından fazla ise bildirim gönder
  if (count > totalProducts / 2) {
    sendNotificationToApp(count);
  }
}

// Uygulamaya bildirim gönderme fonksiyonu
void sendNotificationToApp(int currentProducts) {
  if (Firebase.setString(firebaseData, "/notifications/message", 
    String(PRODUCT_NAME) + " stock is running low! Sold products: " + String(currentProducts))) {
    Serial.println("Notification message sent.");
  } else {
    Serial.print("Firebase error (notification): ");
    Serial.println(firebaseData.errorReason());
  }
}
